$('img').click(function() {
    // alert("hola");
    $(this).hide();
});




$('#reset-btn').click(function(){

  $('img').show();

})